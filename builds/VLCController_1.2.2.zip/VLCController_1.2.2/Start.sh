# !/bin/bash

java controller.Main "conf"

sleep 10